# AMAN ONLINE TEST APP — Setup Guide (Hindi)

यह एक deploy करने योग्य शुरुआती project है: responsive website + Android पर install होने वाला PWA. यह अपने-आप public internet पर publish नहीं होता। Online login/data के लिए आपका Supabase project और hosting account जरूरी है।

## 1) Database बनाइए
1. https://supabase.com पर अपना account बनाकर नया project बनाएं।
2. Project के SQL Editor में `supabase/schema.sql` की पूरी सामग्री paste करके Run करें।
3. Authentication > Providers में Email provider enabled रखें और email confirmations बंद रखें (student accounts Edge Function से confirmed बनते हैं)।

## 2) पहला Teacher account
1. Supabase Dashboard > Authentication > Users > Add user में Teacher का email और मजबूत password बनाएं।
2. उस user की UUID कॉपी करें।
3. SQL Editor में यह query चलाएं (अपनी जानकारी भरें):
   `insert into public.profiles(id,role,full_name) values ('TEACHER-UUID-HERE','teacher','Teacher Name');`
4. Teacher login email और password से होगा।

## 3) Student ID/Password बनाने की सुविधा
Supabase CLI install करके project link करें, फिर:
- `supabase functions deploy create-student`
- Edge Function में Supabase की default environment variables उपलब्ध होनी चाहिए। Service Role Key कभी frontend `.env` में न डालें।
Teacher dashboard से student ID, नाम, class और temporary password बनाएं।

## 4) Website चलाना
1. Node.js 20+ install करें।
2. इस folder में `.env.example` की copy बनाकर उसका नाम `.env` रखें।
3. Supabase Project Settings > API से Project URL और anon/public key `.env` में भरें:
   - `VITE_SUPABASE_URL=...`
   - `VITE_SUPABASE_ANON_KEY=...`
4. Terminal में:
   `npm install`
   `npm run dev`
5. Live website के लिए `npm run build` चलाकर `dist` folder को Vercel या Netlify पर deploy करें। Hosting में वही दो VITE variables set करें।

## 5) Android पर install
यह project PWA है। Website HTTPS पर publish होने के बाद Android Chrome में website खोलें > menu (⋮) > Install app / Add to Home screen. इससे फोन में app icon के साथ install हो जाएगा।
Native APK चाहिए तो Android Studio + Capacitor wrapper जोड़कर अलग Android build करना होगा; इस starter में APK binary शामिल नहीं है।

## जरूरी सुरक्षा नोट
- यह starter/demo implementation है, अभी high-stakes परीक्षा के लिए इस्तेमाल न करें।
- प्रश्नों के सही उत्तर फिलहाल browser को भेजे जाते हैं; production exam में server-side grading जरूरी है।
- अभी exam timer, auto-submit, attempt limits, result export, password reset और admin audit logs पूरे नहीं हैं।
- Teacher का पहला account केवल आप बनाएँ। किसी को भी Supabase Service Role Key न दें।
- सभी student passwords सुरक्षित तरीके से दें और कमजोर/shared password न रखें।
