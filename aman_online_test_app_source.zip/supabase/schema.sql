-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 role text not null check(role in ('teacher','student')),
 student_id text unique,
 full_name text not null,
 class_name text,
 created_at timestamptz not null default now()
);
create table public.tests(
 id uuid primary key default gen_random_uuid(),
 title text not null,
 class_name text not null,
 subject text not null,
 duration_minutes int not null default 30 check(duration_minutes between 1 and 300),
 published boolean not null default false,
 created_by uuid not null references public.profiles(id),
 created_at timestamptz not null default now()
);
create table public.questions(
 id uuid primary key default gen_random_uuid(),
 test_id uuid not null references public.tests(id) on delete cascade,
 question_text text not null,
 options jsonb not null,
 correct_index int not null check(correct_index between 0 and 3),
 marks int not null default 1,
 position int not null default 1
);
create table public.attempts(
 id uuid primary key default gen_random_uuid(),
 test_id uuid not null references public.tests(id),
 student_id uuid not null references public.profiles(id),
 submitted_at timestamptz,
 score numeric not null default 0,
 total_marks numeric not null default 0,
 created_at timestamptz not null default now()
);
create table public.attempt_answers(
 id uuid primary key default gen_random_uuid(),
 attempt_id uuid not null references public.attempts(id) on delete cascade,
 question_id uuid not null references public.questions(id),
 selected_index int,
 is_correct boolean not null default false
);
alter table public.profiles enable row level security;
alter table public.tests enable row level security;
alter table public.questions enable row level security;
alter table public.attempts enable row level security;
alter table public.attempt_answers enable row level security;
create or replace function public.current_role() returns text language sql stable security definer set search_path=public as $$ select role from public.profiles where id=auth.uid() $$;
create policy "profiles self or teacher read" on public.profiles for select to authenticated using (id=auth.uid() or public.current_role()='teacher');
create policy "teacher create profile" on public.profiles for insert to authenticated with check (public.current_role()='teacher' and role='student');
create policy "teacher update profiles" on public.profiles for update to authenticated using (public.current_role()='teacher') with check (public.current_role()='teacher');
create policy "teacher manages tests" on public.tests for all to authenticated using (public.current_role()='teacher') with check (public.current_role()='teacher' and created_by=auth.uid());
create policy "students read published class tests" on public.tests for select to authenticated using (published=true and class_name=(select class_name from public.profiles where id=auth.uid()));
create policy "teacher manages questions" on public.questions for all to authenticated using (public.current_role()='teacher') with check (public.current_role()='teacher');
create policy "student reads questions of published tests" on public.questions for select to authenticated using (exists(select 1 from public.tests t where t.id=test_id and t.published=true and t.class_name=(select class_name from public.profiles where id=auth.uid())));
create policy "student inserts own attempts" on public.attempts for insert to authenticated with check (student_id=auth.uid() and public.current_role()='student' and exists(select 1 from public.tests t where t.id=test_id and t.published=true));
create policy "student reads own attempts teacher reads all" on public.attempts for select to authenticated using (student_id=auth.uid() or public.current_role()='teacher');
create policy "student inserts own answers" on public.attempt_answers for insert to authenticated with check (exists(select 1 from public.attempts a where a.id=attempt_id and a.student_id=auth.uid()));
create policy "student reads own answers teacher reads all" on public.attempt_answers for select to authenticated using (exists(select 1 from public.attempts a where a.id=attempt_id and (a.student_id=auth.uid() or public.current_role()='teacher')));
-- Do not expose answer keys to students in a production exam. This starter keeps them in the questions table for simple auto-marking;
-- use a server-side submit function before using this for high-stakes exams.
