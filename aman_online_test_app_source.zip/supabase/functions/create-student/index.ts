import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
Deno.serve(async (req) => {
 if(req.method==='OPTIONS') return new Response('ok',{headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type'}})
 const cors={'Access-Control-Allow-Origin':'*','Content-Type':'application/json'}
 try {
  const url=Deno.env.get('SUPABASE_URL')!, anon=Deno.env.get('SUPABASE_ANON_KEY')!, service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const auth=req.headers.get('Authorization')||''
  const caller=createClient(url,anon,{global:{headers:{Authorization:auth}}})
  const {data:{user},error:ue}=await caller.auth.getUser()
  if(ue||!user) return new Response(JSON.stringify({error:'Unauthorized'}),{status:401,headers:cors})
  const admin=createClient(url,service)
  const {data:teacher}=await admin.from('profiles').select('role').eq('id',user.id).single()
  if(teacher?.role!=='teacher') return new Response(JSON.stringify({error:'Teacher access required'}),{status:403,headers:cors})
  const body=await req.json(), id=String(body.student_id||'').trim().toUpperCase(), name=String(body.name||'').trim(), cls=String(body.class_name||'').trim(), password=String(body.password||'')
  if(!/^[A-Z0-9_-]{3,30}$/.test(id)||!name||!cls||password.length<8) return new Response(JSON.stringify({error:'Valid ID, name, class and password (8+ chars) required'}),{status:400,headers:cors})
  const email=`${id.toLowerCase()}@students.amanonline.app`
  const {data:created,error}=await admin.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{full_name:name,student_id:id}})
  if(error) throw error
  const {error:pe}=await admin.from('profiles').insert({id:created.user.id,role:'student',student_id:id,full_name:name,class_name:cls})
  if(pe){await admin.auth.admin.deleteUser(created.user.id);throw pe}
  return new Response(JSON.stringify({ok:true,student_id:id}),{headers:cors})
 } catch(e) { return new Response(JSON.stringify({error:e.message||'Server error'}),{status:400,headers:cors}) }
})
