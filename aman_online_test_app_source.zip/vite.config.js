import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
export default defineConfig({ plugins:[react(), VitePWA({ registerType:'autoUpdate', includeAssets:[], manifest:{name:'Aman Online Test App',short_name:'Aman Test',description:'Online tests for all classes',theme_color:'#142b55',background_color:'#ffffff',display:'standalone',start_url:'/',icons:[]} })] })
